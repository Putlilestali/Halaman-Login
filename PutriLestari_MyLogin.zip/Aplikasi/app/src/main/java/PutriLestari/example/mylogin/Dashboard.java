package PutriLestari.example.mylogin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.mylogin.R;

public class Dashboard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
    }
}